library(testthat)
library(gmwm)

test_check("gmwm")
